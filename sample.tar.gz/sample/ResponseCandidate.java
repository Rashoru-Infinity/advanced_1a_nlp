// 雑談対話システムの応答候補を表すクラス

public class ResponseCandidate {
    String response; // 応答候補文
    double score; // その望ましさを表すスコア
}
