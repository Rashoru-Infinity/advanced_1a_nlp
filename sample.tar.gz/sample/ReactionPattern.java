// 雑談対話システムの反応パターンを表すクラス

public class ReactionPattern {
    String keyword; // 反応の基となるキーワード
    String response; // そのキーワードに対する応答文
}
